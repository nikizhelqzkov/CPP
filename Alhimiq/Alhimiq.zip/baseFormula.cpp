#include "baseFormula.h"




BaseFormula::~BaseFormula()
{
}